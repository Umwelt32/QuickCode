#pragma once
#include "defs.hpp"

extern void io_load_data_from_file(std::vector<U8> &data,const std::string &path);



