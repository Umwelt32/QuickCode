#pragma once
#include "defs.hpp"
#include "material.hpp"
#include "texture.hpp"
#include "timer.hpp"

namespace _engine
{
    namespace _engine_layer
    {
        class resources
        {
            public:
                void init(void);
                void deinit(void);
                _engine_vram_adapter::Material &createMaterial(const std::string &name);
                Timer &createTimer(const std::string &name);
                _engine_vram_adapter::Texture &createTexture(const std::string &name);

                _engine_vram_adapter::Material &getMaterial(const std::string &name);
                Timer &getTimer(const std::string &name);
                _engine_vram_adapter::Texture &getTexture(const std::string &name);
            private:
                std::map<std::string,_engine_vram_adapter::Material*> m_materials;
                std::map<std::string,_engine_vram_adapter::Texture*> m_textures;
                std::map<std::string,Timer*> m_timers;
        };
    }
}

