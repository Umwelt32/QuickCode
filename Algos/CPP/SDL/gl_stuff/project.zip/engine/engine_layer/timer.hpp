#pragma once
#include "defs.hpp"

namespace _engine
{
    namespace _engine_layer
    {
        class timer
        {
            public:
                void start(void);
                void stop(void);
                void reset(U32 *outMs_u32);
                void delta(F32 *outSecodns_f32);
                const bool &isRunning(void)const;
                U32 getTimeMs(void);
            private:
                U32 m_start_ms_u32;
                U32 m_stop_ms_u32;
                bool m_is_running;
        };
        typedef timer Timer;
    }
}
