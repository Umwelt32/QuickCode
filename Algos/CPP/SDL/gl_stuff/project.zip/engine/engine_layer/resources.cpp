#include "resources.hpp"

namespace _engine
{
    namespace _engine_layer
    {
        void resources::init(void)
        {
            m_materials.clear();
            m_textures.clear();
            m_timers.clear();
        }

        void resources::deinit(void)
        {
            ;
        }

        _engine_vram_adapter::Material &resources::createMaterial(const std::string &name)
        {
            _DBG_MSG_("CREATE_SHADER: "+name);
            _engine_vram_adapter::Material *m = new _engine_vram_adapter::Material();
            m->init();
            m_materials[name]=m;
            return (*m);
        }

        Timer &resources::createTimer(const std::string &name)
        {
            _DBG_MSG_("CREATE_TIMER: "+name);
            Timer *t=new Timer();
            m_timers[name]=t;
            return (*t);
        }

        _engine_vram_adapter::texture &resources::createTexture(const std::string &name)
        {
            _DBG_MSG_("CREATE_TEXTURE: "+name);
            _engine_vram_adapter::Texture *t=new _engine_vram_adapter::Texture();
            m_textures[name]=t;
            return (*t);
        }

        _engine_vram_adapter::Material &resources::getMaterial(const std::string &name)
        {
            return (*m_materials[name]);
        }

        Timer &resources::getTimer(const std::string &name)
        {
            return (*m_timers[name]);
        }

        _engine_vram_adapter::Texture &resources::getTexture(const std::string &name)
        {
            return (*m_textures[name]);
        }
    }
}
