#include "timer.hpp"
#include "engine.hpp"

namespace _engine
{
    namespace _engine_layer
    {
        void timer::start(void)
        {
            if (m_is_running==false)
            {
                m_start_ms_u32=_engine::_engine_adapter::engine::getInstance().getHardware().getTimeStampMs();
                m_is_running=true;
            }
        }

        void timer::stop(void)
        {
            if (m_is_running==true)
            {
                m_stop_ms_u32=_engine::_engine_adapter::engine::getInstance().getHardware().getTimeStampMs();
                m_is_running=false;
            }
        }

        void timer::reset(U32 *outMs_u32)
        {
            U32 my_time;
            this->stop();
            my_time=getTimeMs();
            this->start();
            if(outMs_u32!=_NULL_PTR_){(*outMs_u32)=my_time;}
        }

        void timer::delta(F32 *outSecodns_f32)
        {
            F32 delta_s;
            U32 time_u32=0;
            this->reset(&time_u32);
            delta_s=((F32)time_u32)/(F32)(1000.0f);
            if(outSecodns_f32!=_NULL_PTR_){(*outSecodns_f32)=delta_s;}
        }

        U32  timer::getTimeMs(void)
        {
            U32 time;
            U32 start = m_start_ms_u32;
            U32 current=m_is_running?_engine::_engine_adapter::engine::getInstance().getHardware().getTimeStampMs():m_stop_ms_u32;
            if(start<current){time=current-start;}else{time=0;}
            return time;
        }

        const bool &timer::isRunning(void)const
        {
            return m_is_running;
        }
    }
}
