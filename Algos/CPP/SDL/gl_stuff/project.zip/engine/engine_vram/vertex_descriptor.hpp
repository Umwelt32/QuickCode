#pragma once
#include "adapter_vertex_descriptor.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    class vertex_descriptor : public adapter_vertex_descriptor
    {
        public:
            void bind(void);
            void unbind(void);
    };
}
}
