#pragma once
#include "adapter_mesh_buffer.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    class mesh_buffer : public adapter_mesh_buffer
    {
        public:
            void init(void);
            void deinit(void);
            void bind(void);
            void draw(void *camera,void *target_texture);
/*--------------------------------------------------------------*/
            virtual mesh_vertex_buffer *getVertexBuffer(void)=0;
        private:
            U32 m_vertex_buffer;
            U32 m_faces_buffer;
    };
}
}
