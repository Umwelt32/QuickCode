#pragma once
#include "adapter_texture.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    class texture : public adapter_texture
    {
        public:
            void bind(void);
            void unBind(void);
    };
    typedef texture Texture;
}
}
