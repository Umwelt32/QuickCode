#pragma once
#include "adapter_material.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    class material : public adapter_material
    {
        public:
            void init(void);
            void use(void);
            void unUse(void);
            void deinit(void);
            void setShader(U8 *shaderData,const U16 &dataSize,const E_SHADER_TYPE &shaderType);
            void link(void);
            void addUniform(const std::string& uniform);
        private:
            S32 getUniform(const std::string& uniform);
            U32 m_program;
            U32 m_shader[EST_COUNT];
            std::map<std::string,S32> m_uniforms;

    };

    typedef material Material;
}
}
