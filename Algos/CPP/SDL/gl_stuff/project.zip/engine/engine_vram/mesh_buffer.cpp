#include "mesh_buffer.hpp"
#include <SDL3/SDL.h>
#include <GL/glew.h>

namespace _engine
{
namespace _engine_vram_adapter
{
    namespace
    {
        constexpr U16 VT_GL_DRAW_TYPE[]={GL_LINES,GL_POINTS,GL_TRIANGLES,GL_QUADS,GL_TRIANGLE_STRIP,GL_PATCHES,0xFFFF};
    }

    void mesh_buffer::init(void)
    {
        glGenBuffers(1, &m_vertex_buffer);
        glGenBuffers(1, &m_faces_buffer);
    }

    void mesh_buffer::deinit(void)
    {
        glDeleteBuffers(1, &m_vertex_buffer);
        glDeleteBuffers(1, &m_faces_buffer);
    }

    void mesh_buffer::bind(void)
    {
        glBindBuffer(GL_ARRAY_BUFFER, m_vertex_buffer);
        glBufferData(GL_ARRAY_BUFFER,this->getVertexBuffer()->getBufferSizeBytes(), this->getVertexBuffer()->getPointer(), GL_STATIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_faces_buffer);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,this->getFacesBuffer().getBufferSizeBytes(), this->getFacesBuffer().getPointer(), GL_STATIC_DRAW);
    }

    void mesh_buffer::draw(void *camera,void *target_texture)
    {
        if(m_materialPtr==nullptr)return;
        if(m_vertexDescriptorPtr==nullptr)return;
        m_vertexDescriptorPtr->bind();
        m_materialPtr->use();
/*--------------------------------------*/
        glBindBuffer(GL_ARRAY_BUFFER, m_vertex_buffer);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_faces_buffer);
        glDrawElements(VT_GL_DRAW_TYPE[m_vertexDescriptorPtr->getDrawMode()], this->getFacesBuffer().getCount(), GL_UNSIGNED_INT, 0);
/*-------------------------------------*/
        m_materialPtr->unUse();
        m_vertexDescriptorPtr->unbind();
    }
}
}
