#pragma once
#include "material.hpp"
#include <SDL3/SDL.h>
#include <GL/glew.h>
#include <stdio.h>
#include <string.h>

namespace _engine
{
namespace _engine_vram_adapter
{
    namespace
    {
        constexpr U32 MY_GL_SHADER_U32[]={GL_VERTEX_SHADER,GL_FRAGMENT_SHADER,GL_GEOMETRY_SHADER,GL_TESS_CONTROL_SHADER,GL_TESS_EVALUATION_SHADER,U32_MAX};
        constexpr std::string_view MY_GL_SHADER_NAME[]={"GL_VERTEX_SHADER","GL_FRAGMENT_SHADER","GL_GEOMETRY_SHADER","GL_TESS_CONTROL_SHADER","GL_TESS_EVALUATION_SHADER","GL_UNKNOW"};
        constexpr U16 MY_GL_ERR_LOG_SIZE_U16 = 512U;
    }

    void material::init(void)
    {
        deinit();
    }

    void material::use(void)
    {
        glUseProgram(m_program);
    }

    void material::unUse(void)
    {
        glUseProgram(0);
    }

    void material::deinit(void)
    {
        for (U8 idx=0;idx<EST_COUNT;++idx){m_shader[idx]=0U;}
        m_uniforms.clear();
        if (m_program!=0)glDeleteProgram(m_program);
        m_program=0;
    }

    void material::setShader(U8 *shaderData,const U16 &dataSize,const E_SHADER_TYPE &shaderType)
    {
        GLsizei err_length=0;
        GLint status=GL_FALSE;
        char err_buf[MY_GL_ERR_LOG_SIZE_U16+1];
        const GLchar* my_shader_data[1]={(GLchar*)&shaderData[0]};
        const GLint my_shader_len[1]={(GLint)dataSize};

        _ASSERT_(shaderType<EST_COUNT);

        m_shader[shaderType] = glCreateShader(MY_GL_SHADER_U32[shaderType]);
        glShaderSource (m_shader[shaderType], 1, &my_shader_data[0], &my_shader_len[0]);
        glCompileShader(m_shader[shaderType]);
        glGetShaderiv  (m_shader[shaderType], GL_COMPILE_STATUS, &status);

        if (status != GL_TRUE)
        {
            memset(&err_buf[0],0,MY_GL_ERR_LOG_SIZE_U16+1);
            glGetShaderInfoLog(m_shader[shaderType], MY_GL_ERR_LOG_SIZE_U16, &err_length, &err_buf[0]);
            err_buf[err_length] = 0;
            _DBG_MSG_("FAIL_TO_COMPILE SHADER!");
            _DBG_MSG_(MY_GL_SHADER_NAME[shaderType].data());
            _DBG_MSG_(err_buf);
            _ASSERT_(0);
        }
    }

    void material::link(void)
    {
        _DBG_MSG_("SHADER_LINK");
        if  (m_program==0){m_program=glCreateProgram();}
        for (U8 idx=0U;idx<EST_COUNT;++idx){if (m_shader[idx]!=0U){glAttachShader(m_program, m_shader[idx]);}}
        /*glBindFragDataLocation(m_program, 0, "out_Color");*/
        glLinkProgram(m_program);
        _ASSERT_(m_program!=0);
    }

    void material::addUniform(const std::string& uniform)
    {
        GLint location;
        location = glGetUniformLocation(m_program, uniform.c_str());
        /*_ASSERT_(location>=0);*/
        m_uniforms[uniform] = location;
    }

    S32 material::getUniform(const std::string& uniform)
    {
        return m_uniforms[uniform];
    }
}
}
