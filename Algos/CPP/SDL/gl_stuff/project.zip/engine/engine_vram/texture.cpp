#pragma once
#include "texture.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    void texture::bind(void)
    {
        ;/*int code=SDL_GL_BindTexture(SDL_Texture *texture, float *texw, float *texh);*/
    }

    void texture::unBind(void)
    {
        ;/*int code=SDL_GL_UnbindTexture(SDL_Texture *texture);*/
    }
}
}
