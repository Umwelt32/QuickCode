#pragma once
#include "adapter_mesh_buffer.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    template <class T>
    class c_mesh_buffer : public mesh_buffer
    {
        public:
            mesh_vertex_buffer *getVertexBuffer(void){return &m_vertex_data;}
        private:
            _engine_utils::c_data_buffer<T> m_vertex_data;

    };
    typedef c_mesh_buffer MeshBuffer;
}
}
