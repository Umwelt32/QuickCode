#include "vertex_descriptor.hpp"
#include <SDL3/SDL.h>
#include <GL/glew.h>

namespace _engine
{
namespace _engine_vram_adapter
{
    namespace
    {
        constexpr U16 VT_GLT[]={GL_INT,GL_UNSIGNED_INT,GL_FLOAT,0xFFFF,0xFFFF,0xFFFF};
        constexpr U16 VT_GL_DRAW_TYPE[]={GL_LINES,GL_POINTS,GL_TRIANGLES,GL_QUADS,GL_TRIANGLE_STRIP,GL_PATCHES,0xFFFF};
    }
    void vertex_descriptor::bind(void)
    {
        E_VRAM_VERTEX_DESC_TYPE_t element_type;
        U8 element_size;
        U8 element_count;
        U16 element_offset;
        for (U32 idx=0; idx<this->count();++idx)
        {
            this->get(idx,_NULL_PTR_,&element_type,&element_size,&element_count,&element_offset);
            glEnableVertexAttribArray(idx);
            glVertexAttribPointer(idx, element_count, VT_GLT[element_type], GL_FALSE, this->getStructureSize(), (const GLvoid*)element_offset);
            /*glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Types::staticVertex), (const GLvoid*)12);*/
        }
    }

    void vertex_descriptor::unbind(void)
    {
        for (U32 idx=0; idx<this->count();++idx)
        {
            glDisableVertexAttribArray(idx);
        }
    }
}
}
