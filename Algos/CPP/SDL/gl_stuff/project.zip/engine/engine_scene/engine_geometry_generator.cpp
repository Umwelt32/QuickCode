#include "engine_geometry_generator.hpp"

namespace _engine
{
namespace _engine_scene
{

    _engine_vram_adapter::adapter_mesh_buffer *geometrycreator::plane(void)
    {
        ;
    }
}
}
