#pragma once
#include "adapter_texture.hpp"
#include "adapter_mesh_buffer.hpp"

namespace _engine
{
namespace _engine_scene
{
    class geometrycreator
    {
        public:
            static _engine_vram_adapter::adapter_mesh_buffer *plane(void);
    };
}
}
