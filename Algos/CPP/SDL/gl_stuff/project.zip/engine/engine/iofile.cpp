#include "iofile.hpp"
#include <SDL3/SDL.h>

#define GET_SDL_FILE(x) (static_cast<SDL_RWops*>(x))

namespace _engine
{
namespace _engine_adapter
{
    void iofile::open(const std::string &path,const bool &binary,const bool &read,const bool &write,const bool &append)
    {
        std::string mode="";
        if (read)mode.push_back('r');
        if (write&&read){mode.push_back('+');}else if(write){mode.push_back('w');}else{;}
        if (binary)mode.push_back('b');
        if (append)mode.push_back('a');
        m_file=SDL_RWFromFile(path.c_str(),mode.c_str());
        if (m_file!=_NULL_PTR_)m_good=true;else m_good=false;
        _ASSERT_(m_good==true);
    }

    void iofile::close(void)
    {
        int code = SDL_RWclose(GET_SDL_FILE(m_file));
        _ASSERT_(code==0);
        m_good=false;
    }

    void iofile::read(U8 *buffer,const U16 &bytes,U16 *readed)
    {
        _ASSERT_(m_good==true);
        size_t data_read = (size_t)bytes;
        size_t size = SDL_RWread(GET_SDL_FILE(m_file),(void*)&buffer[0],data_read);
        if(readed!=_NULL_PTR_){(*readed)=size;}
        if (size<data_read)m_good=false;
    }

    void iofile::write(const U8 *buffer,const U16 &bytes)
    {
        _ASSERT_(m_good==true);
        size_t data_write = (size_t)bytes;
        size_t size = SDL_RWwrite(GET_SDL_FILE(m_file),(void*)&buffer[0], data_write);
        if (size<data_write)m_good=false;
    }

    bool iofile::isGood(void)
    {
        return m_good;
    }

    void iofile::seek(const U32 &offset,const bool &absolute)
    {
        Sint64 pos = SDL_RWseek(GET_SDL_FILE(m_file),offset, absolute?SDL_RW_SEEK_SET:SDL_RW_SEEK_CUR);
        _ASSERT_(pos>=0);
    }

    U32 iofile::tell(void)
    {
        U32 pos4b=0;
        Sint64 pos = SDL_RWtell(GET_SDL_FILE(m_file));
        _ASSERT_(pos>=0);
        if (pos>=0){pos4b=pos;}else{pos4b=0;}
        return pos4b;
    }
}
}
