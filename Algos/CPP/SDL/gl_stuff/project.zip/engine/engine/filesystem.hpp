#pragma once
#include "adapter_filesystem.hpp"
#include "adapter_iofile.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class filesystem : public adapter_filesystem
    {
        public:
            void init(void);
            void deinit(void);
            adapter_iofile *openFile(const std::string &name,const U8 &file_mode);
            void closeFile(adapter_iofile * f);
    };
}
}
