#pragma once
#include "adapter_renderer.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class renderer : public adapter_renderer
    {
        public:
            void init(const std::string &title, const U16 &w,const U16 &h);
            void clear(const glm::vec4 &color);
            void swap(void);
            void deinit(void);
        private:
            void *m_window;
            void *m_context;
    };
}
}
