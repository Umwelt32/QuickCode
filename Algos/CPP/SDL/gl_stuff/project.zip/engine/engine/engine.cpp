#include <SDL3/SDL.h>
#include <GL/glew.h>
#include "engine.hpp"
#include "hardware.hpp"
#include "resources.hpp"

namespace _engine
{
namespace _engine_adapter
{
    void engine::init(void)
    {
        m_engine=this;
        _DBG_MSG_("init");
        m_delta_time_f32=0;
        m_hardware  = std::unique_ptr<hardware>(new hardware());
        m_resources = new _engine_layer::resources();
        _ASSERT_(SDL_Init(SDL_INIT_VIDEO)==0);
        this->getHardware().init();
        this->getResources().init();
        this->getResources().createTimer("engine_delta").start();
        m_running=true;
    }

    void engine::deinit(void)
    {
        _DBG_MSG_("deinit");
        this->getResources().deinit();
        this->getHardware().deinit();
        SDL_Quit();
    }

    void engine::startFrame(void)
    {
        getHardware().getRenderer().clear(glm::vec4(0.5f,0.5f,0.5f,0));
        this->pollEvents();
    }

    void engine::endFrame(void)
    {
        getHardware().getRenderer().swap();
        this->getResources().getTimer("engine_delta").delta(&m_delta_time_f32);
    }

    void engine::pollEvents(void)
    {
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            ;
        }
    }

    bool engine::isRunning(void)
    {
        return m_running;
    }

    adapter_hardware &engine::getHardware(void)const
    {
        return (*m_hardware);
    }
}
}
