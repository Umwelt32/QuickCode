#pragma once
#include <SDL3/SDL.h>
#include "hardware.hpp"
#include "filesystem.hpp"
#include "renderer.hpp"

namespace _engine
{
namespace _engine_adapter
{
    void hardware::init(void)
    {
        m_filesystem = std::unique_ptr<filesystem>(new filesystem());
        m_renderer   = std::unique_ptr<renderer>(new renderer());
        m_filesystem->init();
        m_renderer->init("test",800,600);
    }

    void hardware::deinit(void)
    {
        m_renderer->deinit();
        m_filesystem->deinit();
    }

    U32 hardware::getTimeStampMs(void)
    {
        U32 timestamp=SDL_GetTicks();
        return timestamp;
    }

    void hardware::sleep(const U32 &delayMs_u32)
    {
        SDL_Delay(delayMs_u32);
    }

    adapter_filesystem &hardware::getFilesystem(void)const
    {
        return (*m_filesystem);
    }

    adapter_renderer   &hardware::getRenderer(void)const
    {
        return (*m_renderer);
    }
}
}
