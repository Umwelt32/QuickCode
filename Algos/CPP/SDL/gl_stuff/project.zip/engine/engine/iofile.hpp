#pragma once
#include "adapter_iofile.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class iofile : public adapter_iofile
    {
        public:
            void open(const std::string &path,const bool &binary,const bool &read=true,const bool &write=false,const bool &append=false);
            void close(void);
            void read(U8 *buffer,const U16 &bytes,U16 *readed);
            void write(const U8 *buffer,const U16 &bytes);
            bool isGood(void);
            void seek(const U32 &offset,const bool &absolute);
            U32  tell(void);
        private:
            void *m_file;
            bool m_good;
    };
}
}

