#pragma once
#include "adapter_engine.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class engine : public adapter_engine
    {
        public:
            void init(void);
            void deinit(void);
            void startFrame(void);
            void endFrame(void);
            void pollEvents(void);
            bool isRunning(void);
            adapter_hardware &getHardware(void)const;
        private:
            std::unique_ptr<adapter_hardware> m_hardware;
            bool m_running;

    };
}
}
