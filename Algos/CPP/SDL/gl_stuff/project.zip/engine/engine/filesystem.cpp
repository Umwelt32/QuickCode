#include "filesystem.hpp"
#include "iofile.hpp"

namespace _engine
{
namespace _engine_adapter
{
    void filesystem::init(void)
    {
        _DBG_MSG_("init");
    }

    void filesystem::deinit(void)
    {
        _DBG_MSG_("deinit");
    }

    adapter_iofile *filesystem::openFile(const std::string &name,const U8 &file_mode)
    {
        adapter_iofile *f=new iofile();
        f->open(name,file_mode&E_FILE_MODE_BINARY,file_mode&E_FILE_MODE_READ,file_mode&E_FILE_MODE_WRITE,file_mode&E_FILE_MODE_APPEND);
        return f;
    }

    void filesystem::closeFile(adapter_iofile * f)
    {
        f->close();
        delete f;
    }
}
}
