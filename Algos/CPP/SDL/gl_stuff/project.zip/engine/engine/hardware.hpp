#pragma once
#include "adapter_hardware.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class hardware : public adapter_hardware
    {
        public:
            void init(void);
            void deinit(void);
            U32 getTimeStampMs(void);
            void sleep(const U32 &delayMs_u32);
            adapter_filesystem &getFilesystem(void)const;
            adapter_renderer   &getRenderer(void)const;
        private:
            std::unique_ptr<adapter_filesystem> m_filesystem;
            std::unique_ptr<adapter_renderer> m_renderer;
    };
}
}
