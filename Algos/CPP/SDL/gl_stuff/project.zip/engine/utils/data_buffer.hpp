#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_utils
{
    class data_buffer
    {
        public:
            data_buffer(void);
            virtual ~data_buffer(void);

            virtual void *getFirst(void);
            virtual void *getPointer(void);
            virtual void *getLast(void );
            virtual void *operator[](const U32 &index);
            virtual U32 getBufferSizeBytes(void);

            virtual void *get(const U32 &idx)=0;
            virtual U32   getCount(void)=0;
            virtual void  push(void *elementPtr)=0;
            virtual void  clear(void)=0;
            virtual void  resize(const U32 &cnt)=0;
            virtual U16 getElementSizeBytes(void)=0;
            virtual void setData(void *data, const U32 &count)=0;

        protected:
    };
}
}
