#include "data_buffer.hpp"

namespace _engine
{
namespace _engine_utils
{
    data_buffer::data_buffer(void)
    {
        ;
    }

    data_buffer::~data_buffer(void)
    {
        clear();
    }

    void *data_buffer::getFirst(void)
    {
        return (this->get(0));
    }

    void *data_buffer::getPointer(void)
    {
        return (this->getFirst());
    }

    void *data_buffer::getLast(void )
    {
        void *e=nullptr;
        U32 cnt = this->getCount();
        if(cnt>0U){e=this->get(cnt-1U);}
        return e;
    }

    void *data_buffer::operator[](const U32 &index)
    {
        return (this->get(index));
    }

    U32 data_buffer::getBufferSizeBytes(void)
    {
        return (U32)(this->getElementSizeBytes()*this->getCount());
    }
}
}
