#pragma once
#include "data_buffer.hpp"

namespace _engine
{
namespace _engine_utils
{
    template <class T>
    class c_data_buffer : public data_buffer
    {
        public:
            c_data_buffer():data_buffer(){clear();}
            void *get(const U32 &idx){void *ptr=nullptr;if(m_externalPtr==nullptr){ptr=&m_data[idx];}else{ptr=(void*)&m_externalPtr[idx];};return ptr;}
            U32   getCount(void){U32 size = 0;if(m_externalPtr==nullptr){size=m_data.size();}else{size=m_externalCount;}return size;}
            T &getElement(const U32 &idx){T* e = (T*)this->get(idx);return (*e);}
            void  clear(void){m_externalPtr=nullptr;m_data.clear();}
            void  resize(const U32 &cnt){m_data.resize(cnt);}
            U16 getElementSizeBytes(void){return (U16)sizeof(T);}
            void push(const T &element){m_data.push_back(element);}
            void  push(void *elementPtr)
            {
                T element;
                U16 size  = this->getElementSizeBytes();
                _MEMSET_(&element,0,size);
                _MEMCPY_(&element,elementPtr,size);
                m_data.push_back(element);
            }

            void setData(void *data, const U32 &count)
            {
                T* elements = (T*)data;
                U16 size  = this->getElementSizeBytes();
                this->clear();
                this->resize(count);
                for (U32 i=0; i < this->getCount();++i)
                {
                    _MEMSET_(&m_data[i],0,size);
                    _MEMCPY_(&m_data[i],&elements[i],size);
                }
            }

            void setExternalData(void* data, const U32 &count)
            {
                m_externalCount=count;
                m_externalPtr=(T*)data;
            }

        private:
            std::vector<T> m_data;
            T* m_externalPtr;
            U32 m_externalCount;
    };
}
}
