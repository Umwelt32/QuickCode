#pragma once

#include <cstdio>
#include <iostream>
#include <vector>
#include <memory>
#include <map>
#include <stdio.h>
#include <string.h>
#include <string_view>

#include <glm/vec3.hpp> // glm::vec3
#include <glm/vec4.hpp> // glm::vec4, glm::ivec4
#include <glm/mat4x4.hpp> // glm::mat4

#define U32_MAX (0xFFFFFFFFU)

#define _ASSERT_(x) {SDL_assert(x);}
#define _DBG_MSG_(x) {printf("[%s:%s:%u]=> %s\n",__FILE__,__FUNCTION__,__LINE__,std::string(x).c_str());}
#define _NULL_PTR_ (nullptr)
#define _MEMCPY_(dst,src,len){memcpy(dst,src,len);}
#define _MEMSET_(dst,val,len){memset(dst,val,len);}

typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned int U32;

typedef char S8;
typedef short S16;
typedef int S32;

typedef float F32;
typedef double F64;

