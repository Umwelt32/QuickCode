#pragma once
#include "defs.hpp"
#include "adapter_filesystem.hpp"
#include "adapter_renderer.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class adapter_hardware
    {
        public:
            virtual void init(void)=0;
            virtual void deinit(void)=0;
            virtual U32 getTimeStampMs(void)=0;
            virtual void sleep(const U32 &delayMs_u32)=0;
            virtual adapter_filesystem &getFilesystem(void)const=0;
            virtual adapter_renderer   &getRenderer(void)const=0;
    };
}
}
