#include "adapter_filesystem.hpp"

namespace _engine
{
namespace _engine_adapter
{
    namespace
    {
        constexpr U16 TEMP_BUFFER_SIZE_U16 = 128;
    }

    void adapter_filesystem::loadData(const std::string &name,std::vector<U8> &data)
    {
        U16 readed_u16;
        U8 buffer[TEMP_BUFFER_SIZE_U16];
        adapter_iofile *file = this->openFile(name,E_FILE_MODE_BINARY|E_FILE_MODE_READ);
        data.clear();
        while(file->isGood())
        {
            readed_u16=0;
            file->read(&buffer[0],TEMP_BUFFER_SIZE_U16,&readed_u16);
            for(U16 idx=0;idx<readed_u16;++idx){data.push_back(buffer[idx]);}
        }
        data.push_back(0);
        this->closeFile(file);
    }
}
}
