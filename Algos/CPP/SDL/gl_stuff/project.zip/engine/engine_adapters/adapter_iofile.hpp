#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class adapter_iofile
    {
        public:
            virtual void open(const std::string &path,const bool &binary,const bool &read=true,const bool &write=false,const bool &append=false)=0;
            virtual void close(void)=0;
            virtual void read(U8 *buffer,const U16 &bytes,U16 *readed)=0;
            virtual void write(const U8 *buffer,const U16 &bytes)=0;
            virtual bool isGood(void)=0;
            virtual void seek(const U32 &offset,const bool &absolute)=0;
            virtual U32 tell(void)=0;
    };
}
}
