#include "adapter_engine.hpp"
#include "resources.hpp"

namespace _engine
{
namespace _engine_adapter
{
    adapter_engine *adapter_engine::m_engine=nullptr;
    adapter_engine &adapter_engine::getInstance(void){return (*m_engine);}
    _engine_layer::resources &adapter_engine::getResources(void)const
    {
        return (*m_resources);
    }

    const F32 &adapter_engine::getDeltaTime(void)const
    {
        return m_delta_time_f32;
    }
}
}
