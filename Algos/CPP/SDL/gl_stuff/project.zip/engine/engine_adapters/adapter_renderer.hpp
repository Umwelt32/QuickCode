#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_adapter
{
    class adapter_renderer
    {
        public:
            virtual void init(const std::string &title,const U16 &w,const U16 &h)=0;
            virtual void clear(const glm::vec4 &color)=0;
            virtual void swap(void)=0;
            virtual void deinit(void)=0;
    };
}
}
