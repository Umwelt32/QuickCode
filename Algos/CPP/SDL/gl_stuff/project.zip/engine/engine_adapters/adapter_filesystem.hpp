#pragma once
#include "defs.hpp"
#include "adapter_iofile.hpp"

namespace _engine
{
namespace _engine_adapter
{
    enum E_FILE_MODE
    {
        E_FILE_MODE_BINARY = 1U,
        E_FILE_MODE_READ   = 2U,
        E_FILE_MODE_WRITE  = 4U,
        E_FILE_MODE_APPEND = 8U
    };

    class adapter_filesystem
    {
        public:
            virtual void init(void)=0;
            virtual void deinit(void)=0;
            virtual adapter_iofile *openFile(const std::string &name,const U8 &file_mode)=0;
            virtual void closeFile(adapter_iofile * f)=0;
/*-----------------------*/
            void loadData(const std::string &name,std::vector<U8> &data);
    };
}
}
