#pragma once
#include "defs.hpp"
#include "adapter_hardware.hpp"

namespace _engine
{
namespace _engine_layer
{
    class resources;
}
namespace _engine_adapter
{
    class adapter_engine
    {
        public:
            virtual void init(void)=0;
            virtual void deinit(void)=0;
            virtual void startFrame(void)=0;
            virtual void endFrame(void)=0;
            virtual void pollEvents(void)=0;
            virtual bool isRunning(void)=0;
            virtual adapter_hardware &getHardware(void)const=0;
/*----------------------*/
            _engine_layer::resources &getResources(void)const;
            const F32 &getDeltaTime(void)const;
            static adapter_engine &getInstance(void);
        protected:
            F32 m_delta_time_f32;
            _engine_layer::resources *m_resources;
            static adapter_engine *m_engine;
    };
}
}
