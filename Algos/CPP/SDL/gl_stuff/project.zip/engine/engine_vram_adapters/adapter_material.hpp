#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    enum E_SHADER_TYPE
    {
        EST_Vertex = 0,
        EST_Fragment,
        EST_Geometry,
        EST_TessellationControl,
        EST_TessellationEvaluation,
        EST_Unknow,
        EST_COUNT,
        EST_Force32b = U32_MAX
    };

    class adapter_material
    {
        public:
            virtual void init(void)=0;
            virtual void use(void)=0;
            virtual void unUse(void)=0;
            virtual void deinit(void)=0;
            virtual void setShader(U8 *shaderData,const U16 &dataSize,const E_SHADER_TYPE &shaderType)=0;
            virtual void link(void)=0;
            virtual void addUniform(const std::string& uniform)=0;
/*----------------------*/
            void setShaderFromFile(const std::string &filePath,const E_SHADER_TYPE &shaderType);
            void setShadersFromFiles(const std::string &vs,const std::string &fs,const std::string &gs="",const std::string &tcs="",const std::string &tes="");
    };
}
}
