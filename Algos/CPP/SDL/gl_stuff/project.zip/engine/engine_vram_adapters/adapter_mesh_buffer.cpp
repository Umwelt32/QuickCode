#pragma once
#include "adapter_mesh_buffer.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    adapter_mesh_buffer::adapter_mesh_buffer(void)
    {
        m_materialPtr=nullptr;
        m_vertexDescriptorPtr=nullptr;
    }

    adapter_mesh_buffer::~adapter_mesh_buffer(void)
    {
        ;
    }

    void adapter_mesh_buffer::setName(const std::string &name)
    {
        m_name=name;
    }

    void adapter_mesh_buffer::setMaterial(adapter_material *m)
    {
        m_materialPtr=m;
    }

    const std::string &adapter_mesh_buffer::getName(void)const
    {
        return m_name;
    }

    mesh_index_buffer &adapter_mesh_buffer::getFacesBuffer(void)
    {
        return m_faces;
    }

    adapter_material &adapter_mesh_buffer::getMaterial(void)const
    {
        return (*m_materialPtr);
    }

    void adapter_mesh_buffer::setVertexDescriptor(adapter_vertex_descriptor *v)
    {
        m_vertexDescriptorPtr=v;
    }

    adapter_vertex_descriptor &adapter_mesh_buffer::getVertexDescriptor(void)const
    {
        return (*m_vertexDescriptorPtr);
    }

}
}
