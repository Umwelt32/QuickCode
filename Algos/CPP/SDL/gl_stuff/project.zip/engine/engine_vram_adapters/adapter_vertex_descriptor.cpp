#pragma once
#include "adapter_vertex_descriptor.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    adapter_vertex_descriptor::adapter_vertex_descriptor(void)
    {
        clear();
    }

    adapter_vertex_descriptor::~adapter_vertex_descriptor(void)
    {
        clear();
    }

    void adapter_vertex_descriptor::setDrawMode(const E_MESHBUFFER_DRAW_MODE_t &mode)
    {
        m_drawMode=mode;
    }

    void adapter_vertex_descriptor::clear(void)
    {
        m_structure_size=0;
        m_field.clear();
    }

    void adapter_vertex_descriptor::add(const std::string &name,const E_VRAM_VERTEX_DESC_TYPE_t &type,const U8 &element_size,const U8 &element_count)
    {
        v_desc_t e;
        e.name=name;
        e.type=type;
        e.element_size=element_size;
        e.element_count=element_count;
        e.element_offset=m_structure_size;
        m_structure_size+=(element_size*element_count);
        m_field.push_back(e);
    }

    U16 adapter_vertex_descriptor::count(void)
    {
        return m_field.size();
    }

    void adapter_vertex_descriptor::get(const U16 &idx,std::string *name,E_VRAM_VERTEX_DESC_TYPE_t *type,U8 *element_size,U8 *element_count,U16 *element_offset)
    {
        if (idx<count())
        {
            if(name!=_NULL_PTR_){(*name)=m_field[idx].name;}
            if(type!=_NULL_PTR_){(*type)=m_field[idx].type;}
            if(element_size!=_NULL_PTR_){(*element_size)=m_field[idx].element_size;}
            if(element_count!=_NULL_PTR_){(*element_count)=m_field[idx].element_count;}
            if(element_offset!=_NULL_PTR_){(*element_offset)=m_field[idx].element_offset;}
        }
    }

    const U16 &adapter_vertex_descriptor::getStructureSize(void)const
    {
        return m_structure_size;
    }

    const E_MESHBUFFER_DRAW_MODE_t &adapter_vertex_descriptor::getDrawMode(void)const
    {
        return m_drawMode;
    }
}
}
