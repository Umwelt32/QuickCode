#pragma once
#include "defs.hpp"
#include "c_data_buffer.hpp"
#include "adapter_material.hpp"
#include "adapter_vertex_descriptor.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    typedef _engine_utils::c_data_buffer<U32> mesh_index_buffer;
    typedef _engine_utils::data_buffer mesh_vertex_buffer;
    class adapter_mesh_buffer
    {
        public:
            adapter_mesh_buffer(void);
            virtual ~adapter_mesh_buffer(void);
            virtual void setName(const std::string &name);
            virtual void setMaterial(adapter_material *m);
            virtual void setVertexDescriptor(adapter_vertex_descriptor *v);

            virtual adapter_vertex_descriptor &getVertexDescriptor(void)const;
            virtual adapter_material &getMaterial(void)const;
            virtual const std::string &getName(void)const;
            virtual mesh_index_buffer &getFacesBuffer(void);
/*----------------------------------------------------------------*/
            virtual void init(void)=0;
            virtual void deinit(void)=0;
            virtual void bind(void)=0;
            virtual void draw(void *camera,void *target_texture)=0;
            virtual mesh_vertex_buffer *getVertexBuffer(void)=0;
        protected:
            std::string m_name;
            adapter_material *m_materialPtr;
            adapter_vertex_descriptor *m_vertexDescriptorPtr;
            mesh_index_buffer m_faces;
        private:


    };
}
}
