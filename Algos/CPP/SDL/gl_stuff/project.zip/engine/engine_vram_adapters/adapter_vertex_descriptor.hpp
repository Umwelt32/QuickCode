#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    typedef enum
    {
        E_VVD_INT=0,
        E_VVD_UINT,
        E_VVD_FLOAT,
        E_VVD_UNKNOW,
        E_VVD_NOT_USED,
        E_VVD_COUNT
    }E_VRAM_VERTEX_DESC_TYPE_t;

    typedef enum
    {
        EMDM_POINTS,
        EMDM_LINES,
        EMDM_TRIANGLES,
        EMDM_TRIANGLE_STRIP,
        EMDM_QUADS,
        EMDM_PATCHES,
        EMDM_COUNT
    }E_MESHBUFFER_DRAW_MODE_t;

    typedef struct
    {
        std::string name;
        E_VRAM_VERTEX_DESC_TYPE_t type;
        U8 element_size;
        U8 element_count;
        U16 element_offset;
    }v_desc_t;

    class adapter_vertex_descriptor
    {
        public:
            adapter_vertex_descriptor(void);
            virtual ~adapter_vertex_descriptor(void);
            virtual void setDrawMode(const E_MESHBUFFER_DRAW_MODE_t &mode);
            virtual void add(const std::string &name,const E_VRAM_VERTEX_DESC_TYPE_t &type,const U8 &element_size,const U8 &element_count);
            virtual void get(const U16 &idx,std::string *name,E_VRAM_VERTEX_DESC_TYPE_t *type,U8 *element_size,U8 *element_count,U16 *element_offset);
            virtual const U16 &getStructureSize(void)const;
            virtual const E_MESHBUFFER_DRAW_MODE_t &getDrawMode(void)const;
            virtual U16 count(void);
            virtual void clear(void);
            virtual void bind(void)=0;
            virtual void unbind(void)=0;
        protected:
            std::vector<v_desc_t> m_field;
            U16 m_structure_size;
            E_MESHBUFFER_DRAW_MODE_t m_drawMode;

    };
}
}
