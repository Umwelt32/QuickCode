#pragma once
#include "adapter_material.hpp"
#include "adapter_engine.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    void adapter_material::setShaderFromFile(const std::string &filePath,const E_SHADER_TYPE &shaderType)
    {
        std::vector<U8> data;
        if (filePath.length()>0)
        {
            _DBG_MSG_("LOAD_SHADER: "+filePath);
            _engine::_engine_adapter::adapter_engine::getInstance().getHardware().getFilesystem().loadData(filePath,data);
            this->setShader(&data[0],data.size(),shaderType);
        }
    }

    void adapter_material::setShadersFromFiles(const std::string &vs,const std::string &fs,const std::string &gs,const std::string &tcs,const std::string &tes)
    {
        setShaderFromFile(vs,EST_Vertex);
        setShaderFromFile(fs,EST_Fragment);
        setShaderFromFile(gs,EST_Geometry);
        setShaderFromFile(tcs,EST_TessellationControl);
        setShaderFromFile(tes,EST_TessellationEvaluation);
        this->link();
    }
}
}
