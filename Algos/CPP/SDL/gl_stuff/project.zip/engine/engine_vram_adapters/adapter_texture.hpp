#pragma once
#include "defs.hpp"

namespace _engine
{
namespace _engine_vram_adapter
{
    class adapter_texture
    {
        public:
            virtual void bind(void)=0;
            virtual void unBind(void)=0;
    };
}
}
