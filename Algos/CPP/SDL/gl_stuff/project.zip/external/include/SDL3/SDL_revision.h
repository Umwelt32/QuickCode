/* #undef SDL_VENDOR_INFO */

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-3.0.0-no-vcs (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-3.0.0-no-vcs"
#endif
