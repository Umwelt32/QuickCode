#include <iostream>
#include "engine.hpp"
#include "resources.hpp"
#include "c_data_buffer.hpp"

using namespace std;

int main()
{
    _engine::_engine_adapter::engine eng;
    eng.init();
    eng.getResources().createMaterial("test").setShadersFromFiles("data/vs.txt","data/fs.txt");
    eng.getResources().getMaterial("test").addUniform("test");
    while(eng.isRunning())
    {
        eng.startFrame();
        eng.getHardware().sleep(100);
        //std::cout<<eng.getDeltaTime()<<std::endl;
        eng.endFrame();
    }
    eng.deinit();
    cout << "Hello world!" << endl;
    return 0;
}
